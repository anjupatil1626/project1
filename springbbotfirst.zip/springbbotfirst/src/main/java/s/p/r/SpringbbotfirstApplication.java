package s.p.r;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbbotfirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbbotfirstApplication.class, args);
	}

}
