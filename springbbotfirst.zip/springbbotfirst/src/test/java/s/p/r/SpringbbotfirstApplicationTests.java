package s.p.r;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbbotfirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
